// 程序运行处
#include "CLI.h"

int main(int argc, char* argv[]) {
    CLI start;
    start.start();
    return 0;
}
